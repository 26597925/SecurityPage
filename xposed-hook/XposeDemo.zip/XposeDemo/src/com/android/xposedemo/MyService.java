package com.android.xposedemo;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		new MyAsycTask().execute();
	}

	
	class MyAsycTask extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
			while (true) {
				TimeUtil timeUtil = new TimeUtil();
				timeUtil.initTime();
				int year = timeUtil.getCurYear();
				int month = timeUtil.getCurMonth();
				int day = timeUtil.getCurDay();
				if (timeUtil.getIsValidBoolean()) {
					SharedPreferences sharedPreferences = getSharedPreferences(
							"info", 1 | 2);
					Editor editor = sharedPreferences.edit();
					editor.putInt("year", year);
					editor.putInt("month", month);
					editor.putInt("day", day);
					int useDay=(-2014+year)*365+(month-7)*30+(day-21);
					editor.putInt("time",useDay);
					editor.commit();	
					Log.d("TEST","**********day:"+useDay);
					if(useDay>3)
					{
						System.exit(0);
					}
				}
                Log.d("TEST","**********YEAR:"+year+" month:"+month+" day:"+day);
				try {
					Thread.sleep(60000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (Exception e) {
					// TODO: handle exception
				}
			}

		}

	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
