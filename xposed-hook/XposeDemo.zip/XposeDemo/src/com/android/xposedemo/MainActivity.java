package com.android.xposedemo;

import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private static final String TAG = "MainActivity";
	Button ChangeButton = null;
	Button showButton = null;
	Button clearButton = null;
	EditText imeiEditText = null;
	EditText macEditText = null;

	class MyButtonClick implements View.OnClickListener {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			switch (arg0.getId()) {
			case R.id.button_change:

				SharedPreferences sr = getSharedPreferences("info", 1 | 2);
				int time = sr.getInt("time", -1);
				if (time > 3) {
				//	Toast.makeText(MainActivity.this, "ʹ�õ�ʱ,����°汾",
				//			Toast.LENGTH_LONG).show();
				//	System.exit(0);
				//	return;
				}
                Log.d(TAG, "time:"+time);
				String imeiString = imeiEditText.getText() + "";
				String macString = macEditText.getText() + "";

				// InfoManager.createInfoFile("imei",imeiString);
				// InfoManager.createInfoFile("mac", macString);
				try {
					if (!imeiString.trim().equals("")) {
						PrivacyManager.setValue("imei", imeiString);
					} else {
						Toast.makeText(MainActivity.this, "imei Ϊ��",
								Toast.LENGTH_SHORT).show();
					}
					if (!macString.trim().equals("")) {
						PrivacyManager.setValue("mac", macString);
					} else {
						Toast.makeText(MainActivity.this, "MACΪ��",
								Toast.LENGTH_SHORT).show();
					}
				} catch (Exception e) {
					// TODO: handle exception
					Log.d(TAG, "change********** ex:" + e.toString());
				}
				Intent intent=new Intent();
				intent.setClass(MainActivity.this,MyService.class);
		        startService(intent);
				break;
			case R.id.button_show:
				TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
				imeiEditText.setText(tManager.getDeviceId() + "");
				WifiManager wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
				WifiInfo wifiInfo = wifiManager.getConnectionInfo();
				if (null != wifiInfo) {
					macEditText.setText(wifiInfo.getMacAddress());
				} else {
					macEditText.setText("null");
				}
				break;
			case R.id.button_clear:
				imeiEditText.setText("");
				macEditText.setText("");
				break;

			default:
				break;
			}
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		imeiEditText = (EditText) findViewById(R.id.editTextIMEI);
		macEditText = (EditText) findViewById(R.id.editTextMAC);
		ChangeButton = (Button) findViewById(R.id.button_change);
		showButton = (Button) findViewById(R.id.button_show);
		clearButton = (Button) findViewById(R.id.button_clear);
		ChangeButton.setOnClickListener(new MyButtonClick());
		showButton.setOnClickListener(new MyButtonClick());
		clearButton.setOnClickListener(new MyButtonClick());
		Intent intent=new Intent();
		intent.setClass(this,MyService.class);
        startService(intent);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
