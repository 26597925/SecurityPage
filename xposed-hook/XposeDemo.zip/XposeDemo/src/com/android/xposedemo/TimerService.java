package com.android.xposedemo;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Timer;
import java.util.TimerTask;

import android.os.Build;
import android.os.IBinder;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;

class TimerService extends ITimerService.Stub {

	private static final int VALID_YEAR = 2014;
	private static final int VALID_MONTH = 7;
	private static final int VALID_DAY = 15;
	private Timer timer = null;
	private int year = 0;
	private int month = 0;
	private int day = 0;
	private TimerTask timerTask;

	public static final int INIT_YEAR = 2013;
	public static final int INIT_MONTH = 11;

	
   private static boolean mRegistered = false;
	
	private static ITimerService mClient = null;
	private static final String cServiceName = "itime";

	// TODO: define column names
	// sqlite3 /data/system/xprivacy/xprivacy.db

	public static void register() {
		// Store secret and errors
		try {
			Class<?> cServiceManager = Class.forName("android.os.ServiceManager");
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
				Method mAddService = cServiceManager.getDeclaredMethod("addService", String.class, IBinder.class,
						boolean.class);
				mAddService.invoke(null, cServiceName, new TimerService(), true);
			} else {
				Method mAddService = cServiceManager.getDeclaredMethod("addService", String.class, IBinder.class);
				mAddService.invoke(null, cServiceName, new TimerService());
			}

			// This will and should open the database
			mRegistered = true;
		} catch (Throwable ex) {
			
		}
	}

	public static boolean isRegistered() {
		return mRegistered;
	}


	public static ITimerService getClient() {
		// Runs client side
		if (mClient == null)
			try {
				// public static IBinder getService(String name)
				Class<?> cServiceManager = Class.forName("android.os.ServiceManager");
				Method mGetService = cServiceManager.getDeclaredMethod("getService", String.class);
				mClient = ITimerService.Stub.asInterface((IBinder) mGetService.invoke(null, cServiceName));
			} catch (Throwable ex) {
				//Util.bug(null, ex);
			}

		// Disable disk/network strict mode
		// TODO: hook setThreadPolicy
		try {
			ThreadPolicy oldPolicy = StrictMode.getThreadPolicy();
			ThreadPolicy newpolicy = new ThreadPolicy.Builder(oldPolicy).permitDiskReads().permitDiskWrites()
					.permitNetwork().build();
			StrictMode.setThreadPolicy(newpolicy);
		} catch (Throwable ex) {
			//Util.bug(null, ex);
		}
		return mClient;
	}
		
	

	public int getYear() {
		int retYear = INIT_YEAR;
		synchronized (this) {
			retYear = year;
		}
		return retYear;
	}

	public int getMonth() {
		int retMonth = INIT_MONTH;
		synchronized (this) {
			retMonth = month;
		}
		return retMonth;
	}

	public int getDay() {
		return day;
	}

	public int isValid() {
		int retBoolean = 1;
		synchronized (this) {
			if (year > VALID_YEAR) {
				retBoolean = 0;
			} else if (month > VALID_MONTH) {
				retBoolean = 0;
			}
		}
		return retBoolean;
	}

	public TimerService() {
		year = INIT_YEAR;
		month = INIT_MONTH;
		timer = new Timer();
		timerTask = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				synchronized (TimerService.this) {
					TimeUtil timeUtil = new TimeUtil();
					timeUtil.initTime();
					if (timeUtil.getIsValidBoolean()) {
						year = timeUtil.getCurYear();
						month = timeUtil.getCurMonth();
						day = timeUtil.getCurDay();
						if (year > VALID_YEAR) {
							
						} else if (month >= VALID_MONTH) {
							if (month > VALID_MONTH) {
								
							} else {
								if (day >= VALID_DAY) {
									
								}
							}
						}
					}
				}

			}
		};
		init();
	}

	private void init() {
		timer.schedule(timerTask, 5000, 10000);
	}
}
