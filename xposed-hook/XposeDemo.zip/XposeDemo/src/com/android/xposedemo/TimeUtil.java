package com.android.xposedemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.util.Log;

public class TimeUtil {

	private int curYear = 0;
	private int curMonth = 0;
	private int curDay = 0;
	private Boolean isValidBoolean = false;

	public Boolean getIsValidBoolean() {
		return isValidBoolean;
	}

	public void setIsValidBoolean(Boolean isValidBoolean) {
		this.isValidBoolean = isValidBoolean;
	}

	public TimeUtil() {

	}

	public int getCurYear() {
		return curYear;
	}

	public void setCurYear(int curYear) {
		this.curYear = curYear;
	}

	public int getCurMonth() {
		return curMonth;
	}

	public void setCurMonth(int curMonth) {
		this.curMonth = curMonth;
	}

	public int getCurDay() {
		return curDay;
	}

	public void setCurDay(int curDay) {
		this.curDay = curDay;
	}

	public void initTime() {
		String urlString = "http://www.beijing-time.org/time.asp";
		StringBuilder stringBuilder = new StringBuilder();
		String timeString = null;
		URL url;
		try {
			url = new URL(urlString);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url
					.openConnection();
			httpURLConnection.connect();
			String lineString = null;
			BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(httpURLConnection.getInputStream()));
			while ((lineString = bufferedReader.readLine()) != null) {
				stringBuilder.append(lineString);
			}
			bufferedReader.close();
			setIsValidBoolean(true);
			// return stringBuilder.toString();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// return null;
			setIsValidBoolean(false);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// return null;
			setIsValidBoolean(false);
		}catch (Exception e) {
			// TODO: handle exception
			setIsValidBoolean(false);
		}
		timeString = stringBuilder.toString().trim().replace("\r", "")
				.replace("\n", "");
		Log.d("DEBUG", "TIME :" + timeString);
		if (getIsValidBoolean()) {

			int yearIndex = timeString.indexOf("nyear=") + "nyear=".length();
			int monthIndex0 = timeString.indexOf(";nmonth=");
			int ndayIndex0 = timeString.indexOf(";nday=");

			int monthIndex = timeString.indexOf("nmonth=") + "mmonth=".length();
			int dayIndex = timeString.indexOf("nday=") + "nday=".length();

			int monthCount = ndayIndex0 - monthIndex;
			int dayCount = timeString.indexOf(";nwday=") - dayIndex;
			String year = timeString.substring(yearIndex, monthIndex0);
			String month = timeString.substring(monthIndex, ndayIndex0);
			String day = timeString.substring(dayIndex,
					timeString.indexOf(";nwday="));
			setCurYear(Integer.parseInt(year));
			setCurMonth(Integer.parseInt(month));
			setCurDay(Integer.parseInt(day));
		} else {
			setCurYear(0);
			setCurMonth(0);
			setCurDay(0);
		}
	}
}
